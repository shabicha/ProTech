//
//  Classification.swift
//  coreML-starter
//
//  
//

struct Classification: Decodable {
    // TODO: replace with the name of your keys from mydata.json and some default values
    var label: String = "Altria Theatre"
    var imageName: String = "Theater"

}
